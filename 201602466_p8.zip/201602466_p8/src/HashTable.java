import java.math.BigInteger;
import java.util.Iterator;

//Overall correctness: 10 marks **********************************************************************
//Overall for HashTable class: 40 marks **************************************************************
/**
 * Hash table using separate chaining.
 */
public class HashTable<K extends Comparable<? super K>,V> implements IMap<K,V> {

    Object[] hashTable;
    int a, b;
    int size = 0;

    /**
     * Default Constructor
     */
    public HashTable() {
        this(1000);
    }

    /**
     * Constructor
     * @param size the size of the hashtable
     */
    public HashTable(int size) {
        hashTable = new Object[size];

        for (int i = 0; i < size; i++) {
            hashTable[i] = new Bucket<K,V>();
        }

        //Calculate prime factors for the MAD calculation
        a = primeSmallerThan(size);
        b = primeSmallerThan(size/2);
    }

    /**
     * Get an element from the hash table or return null
     * @param key The key that should be searched for in the list
     * @return The object that maps to the key or null if it does not exist
     */
    @Override
    public V get(K key) {
        return searchBucket(key);
    }

    /**
     * Put a key/value entry into the hash table
     * @param key the key to add
     * @param value the value to add
     * @return if the item was updated then return the original value, if it was a new item then return null
	 * 8 marks ***********************************************
     */
    @Override
    public V put(K key, V value) {
		//TODO: COMPLETE CODE HERE
    	int index = hash(key);
    // 	int reference = (int)get(index);
    	@SuppressWarnings("unchecked")
		PositionList<Entry<K,V>> list = (PositionList<Entry<K,V>>)(hashTable[index]);
    	
    	while(list.iterator().hasNext()) {
    		Entry<K,V> e = (Entry<K, V>) list.iterator().next();
    		if((e.getKey())==key) {
    			e.setValue(value);
    			return value;
    		}
    		else {
    			
    			Entry<K,V> newEntry = null;
    			list.addLast(newEntry);
    			
    		}
    		size++;
    	}
		return value;
    }

    /**
     * Remove an item from the hash table
     * @param key the key that should be removed
     * @return the value of the item that was removed, otherwise return null
	 * 5 marks ***********************************************
     */
    @Override
    public V remove(K key) {
        //TODO: COMPLETE CODE HERE
    	int index = hash(key); //finding index
    	@SuppressWarnings("unchecked")
		PositionList<Entry<K,V>> list = (PositionList<Entry<K,V>>)(hashTable[index]);
        V tempV=null;
    	while(list.iterator().hasNext()) {
    		Entry<K,V> e = list.iterator().next();
    		
    		if((e.getKey())==key) {
    			list.iterator().remove();
    			 tempV =e.getValue();
    			size--;
    			return tempV;
    		
    		}else { 
    			return null;
    		}
    		
    	}
		return tempV;
	
		
    }

    /**
     * The size of the hash table
     * @return the size of the hash table
     */
    @Override
    public int size() {
        return size;
    }

    /**
     * Return true if the hash table is empty
     * @return return true if the hash table is empty
     */
    @Override
    public boolean isEmpty() {
        return (size == 0);
    }

    /**
     * Return an iterator over the keys in the hash table
     * REMEMBER THAT THIS IS A BUCKET ARRAY - USE AN ITERATOR
     * @return an iterator over all the keys
	 * 5 marks ***********************************************
     */
    @SuppressWarnings("unchecked")
	@Override
    public Iterator<K> keys() {
		//TODO: COMPLETE CODE HERE
    	/*
    	 Entry<K,V> e = null;
    	 
    	@SuppressWarnings("unchecked")
		PositionList<Entry<K,V>> bucketlist = (PositionList<Entry<K,V>>)(hashTable[1000]);
    	@SuppressWarnings("null")
		K keys = e.getKey();
    	if((e.getKey())==keys) 
    	return	(Iterator<K>) bucketlist.iterator();
		return null;
		
    	*/
    	//Create a new PositionList<K> to store the keys
    	PositionList<K> keys = new PositionList<K>();
    	
    	//Use a for loop to iterate over the hash table
    	
    	for(Object obj:hashTable) {
    		Bucket<K,V> bucket = (Bucket<K,V>)obj;
    		
      //Get an iterator over the list at index (iterator() method)
    	Iterator<Entry<K,V>> iter = bucket.bucket.iterator();
    	
    	//As long as the iterator has the next item:
    	while(iter.hasNext()) {
    		Entry<K,V> newEntry = iter.next();
    		
    		//Add the key to the keys list
    		keys.addLast(newEntry.getKey());
    	}
     }
    	return keys.iterator();
   }
    	

    /**
     * Return an iterator over the values in the hash table
     * REMEMBER THAT THIS IS A BUCKET ARRAY - USE AN ITERATOR
     * @return an iterator over all the keys in the hash table.
	 * 5 marks ***********************************************
     */
    @Override
    public Iterator<V> values() {
	
		//TODO: COMPLETE CODE HERE
    	//Create a new PositionList to store values
		PositionList<V> values = new PositionList<>();
		
		//Create a for loop to iterate over the hash table
		for(Object obj:hashTable) {
			@SuppressWarnings("unchecked")
			Bucket<K,V> bucket = (Bucket<K,V>)obj;
			
			//Get an iterator over the list at index(iterator() method)
			Iterator<Entry<K,V>> iter = bucket.bucket.iterator();
			
			//As long as the iterator has the next item:
			while(iter.hasNext()) {
				Entry<K,V> newEntry = iter.next();
				//Add the value to the values list
			    values.addLast(newEntry.getValue());
			}
		}
		return values.iterator();
    	
    }

    /**
     * Get a bucket for a given position
     * This is a utility function to handle the casting between the bucket and the
     * object type for the array
     * @param pos the position to return
     * @return the Bucket for this position
     */
    private Bucket<K,V> getBucket(int pos) {
    	
        return (Bucket<K,V>)hashTable[pos];	//we need to babysit Java here
    }

    /**
     * Search a bucket and return a Position object that corresponds to a key that has been passed
     * The keys are part of the entries and should be comparable.\
     * THIS FUNCTION OPERATES ON POSITONS NOT ON ITERATORS
     * @param key the key to search for
     * @param bucket the bucket (PositionList) to search through
     * @return The Position of the Entry that maps to the key, or null if the entry does not exist.
	 * 5 marks ***********************************************
     */
    private Position<Entry<K,V>> searchBucketPosition(K key, PositionList<Entry<K,V>> bucket) { 
    	//TODO: COMPLETE CODE HERE
    	
    	//check IllegalArguementExcetion(key!=null and bucket!=null)
    	if(key==null) {
    		throw new IllegalArgumentException("key cannot be null");
    		
    	}
    	if(bucket ==null) {
    		throw new IllegalArgumentException("bucket cannot be null");
    	}
    	
    	//Get an iterator over the list at index (iterator() method)
    	Iterator<Entry<K,V>> iter = bucket.iterator();
    	
    	while(iter.hasNext()) {
    		//get next entry in the list
    		Entry<K,V> entry = iter.next();
    		
    		//if the key is found, return the position of the entry
    		if(entry.getKey().equals(key)) {
    			return bucket.search(entry);
    		}
    	}
    	//if entry is not found that is equal to the key inserted then return null
		return null;
    }

    /**
     * Search a bucket for a given key, return the value that is associated with the key
     * USE AN ITERATOR OVER THE BUCKET TO COMPLETE THIS METHOD
     * @param key the key to search for
     * @return the value mapped to the key.
	 * 5 marks ***********************************************
     */
    private V searchBucket(K key) {
    	//TODO: COMPLETE CODE HERE
		//handle exceptions
    	if(key==null) {
    		throw new IllegalArgumentException("key cannot be null");
    	}
        
    	//hash the key
		int index = hash(key);
		
		//get reference of hashed key
		Bucket<K,V> bucket = this.getBucket(index);
		
		//Create iterator to loop through index in hash table
		Iterator<Entry<K,V>> iter = bucket.bucket.iterator();
		
		//iterate...
		while(iter.hasNext()) {
			Entry<K,V> entry = iter.next();
			//if the key is found return the value of the key...
			if(entry.getKey().equals(key)) {
				return entry.getValue();
			}
		}
		//... else return null
		return null;
    }

    /**
     * Compute the hash for an object. This function uses the string represention of the key
     * to build the hash.
     * @param key the key that must be hashed.
     * @return an index for the given key.
     */
    private int hash(K key) {
        return mad(fnv(key.toString().toCharArray()));
    }

    /**
     * Compute a Fowler-Noll-Vo hash over a passed character array.
     * @param data a character array that contains the data to be hashed.
     * @return a 64-bit hash value
	 * 7 marks ***********************************************
     */
    private long fnv(char[] data) {
		//TODO: COMPLETE CODE HERE
    	
    	//handle exceptions
    	if(data==null) {
    		throw new IllegalArgumentException("data cannot be null");
    	}
    	//initialize the hash value using BigInteger
    	BigInteger hash = new BigInteger("1469581039346656037");
    	
    	//Initialize the has fnc value using BigInteger
    	BigInteger fnv = new BigInteger("109951162828211");
    	
    	//for each character in the data
    	for(char c:data) {
    		//Multiply the hash by 109951162828211
    		hash = hash.multiply(fnv);
    		
    		//XOR the hash by the character
    		hash = hash.xor(new BigInteger(String.valueOf(c)));
    	}
    	return Math.abs(hash.longValue());
    }

    /**
     * The compression function: Compress the input hash code into an index for
     * the hash table. This will use the MAD method to compress the hash
     * @param value the hash code to compress
     * @return the index for the hash table.
     */
    private int mad(long value) {
        return Math.abs((int)((a*value + b) % hashTable.length));
    }

    //Sieve out primes less than upperBound
    private int primeSmallerThan(int upperBound) {
        boolean[] array = new boolean[upperBound+1];

        for (int i = 0; i < upperBound+1; i++) {
            array[i] = true;
        }
        array[0] = false;
        array[1] = false;

        //sieve
        for (int j = 2; j < upperBound+1; j+=1) {
            if (array[j]) {
                for (int i = (j * 2); i < upperBound + 1; i += j) {
                    array[i] = false;
                }
            }
        }

        //return
        for (int j = upperBound; j >= 0; j--) {
            if (array[j]) {
                return j;
            }
        }
        return 2; //should never be executed.
    }
}

